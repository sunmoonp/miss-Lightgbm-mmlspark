# Copyright (C) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See LICENSE in project root for information.


"""
MicrosoftML is a library of Python classes to interface with the
Microsoft scala APIs to utilize Apache Spark to create distibuted
machine learning models.

MicrosoftML simplifies training and scoring classifiers and
regressors, as well as facilitating the creation of models using the
CNTK library, images, and text.
"""

from mmlspark.doc.conf import *

