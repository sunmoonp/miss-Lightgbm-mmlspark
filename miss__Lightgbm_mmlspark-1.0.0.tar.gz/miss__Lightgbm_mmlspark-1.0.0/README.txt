Microsoft ML for Apache Spark
=============================

# The primary issue addressed in this build dependency resolution is: ModuleNotFoundError: 
No module named 'mmlspark.lightgbm._LightGBClassifier'.  
For more complete documentation, refer to
the MMLSpark repo: https://github.com/Azure/mmlspark .